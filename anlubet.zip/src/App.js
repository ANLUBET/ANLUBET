// Estrutura base do projeto ANLUBET
// Framework: React + TailwindCSS
// Simulando: Login, Home, Slot, Admin (sem backend real ainda)

import { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from "react-router-dom";

function App() {
  const [user, setUser] = useState(null);
  const isAdmin = user === "admin";

  return (
    <Router>
      <div className="bg-gray-900 text-white min-h-screen p-4">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">ANLUBET</h1>
          {user ? (
            <div className="flex gap-4 items-center">
              <span>Bem-vindo, {user}</span>
              <button onClick={() => setUser(null)} className="bg-red-500 px-3 py-1 rounded">Sair</button>
            </div>
          ) : null}
        </header>
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/login" element={<Login onLogin={setUser} />} />
          <Route path="/slot" element={user ? <Slot user={user} /> : <Navigate to="/login" />} />
          <Route path="/admin" element={isAdmin ? <Admin /> : <Navigate to="/login" />} />
        </Routes>
      </div>
    </Router>
  );
}

function Home({ user }) {
  return (
    <div className="text-center">
      <h2 className="text-xl mb-4">Bem-vindo à plataforma de apostas ANLUBET</h2>
      {user ? (
        <div className="flex justify-center gap-6">
          <Link to="/slot" className="bg-green-600 px-4 py-2 rounded">Jogar Slot</Link>
          {user === "admin" && <Link to="/admin" className="bg-yellow-600 px-4 py-2 rounded">Admin</Link>}
        </div>
      ) : (
        <Link to="/login" className="bg-blue-500 px-4 py-2 rounded">Entrar / Cadastrar</Link>
      )}
    </div>
  );
}

function Login({ onLogin }) {
  const [name, setName] = useState("");

  const handleLogin = () => {
    if (name) {
      onLogin(name);
    }
  };

  return (
    <div className="max-w-sm mx-auto text-center">
      <h2 className="text-xl mb-4">Entrar na ANLUBET</h2>
      <input
        type="text"
        placeholder="Digite seu nome"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="w-full px-3 py-2 mb-3 rounded text-black"
      />
      <button onClick={handleLogin} className="bg-blue-600 px-4 py-2 rounded">Entrar</button>
    </div>
  );
}

function Slot({ user }) {
  const [balance, setBalance] = useState(1000);
  const [result, setResult] = useState(null);
  const symbols = ["🍒", "🍋", "🔔", "💎", "7️⃣"];

  const spin = () => {
    const spinResult = [
      symbols[Math.floor(Math.random() * symbols.length)],
      symbols[Math.floor(Math.random() * symbols.length)],
      symbols[Math.floor(Math.random() * symbols.length)],
    ];
    setResult(spinResult);

    const [a, b, c] = spinResult;
    if (a === b && b === c) {
      setBalance(balance + 500);
    } else {
      setBalance(balance - 100);
    }
  };

  return (
    <div className="text-center">
      <h2 className="text-2xl mb-4">Slot Machine</h2>
      <p className="mb-2">Saldo: R$ {balance}</p>
      <button onClick={spin} className="bg-purple-600 px-4 py-2 mb-4 rounded">Girar</button>
      {result && <div className="text-3xl flex justify-center gap-4">{result.map((r, i) => <span key={i}>{r}</span>)}</div>}
    </div>
  );
}

function Admin() {
  return (
    <div>
      <h2 className="text-xl mb-4">Painel de Administração</h2>
      <p>(Simulação de painel - funcionalidade futura)</p>
    </div>
  );
}

export default App;